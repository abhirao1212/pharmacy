package com.example.system;

public interface Recyclerclicklistener  {
    void onclick(int pos);

}
